# get-protected-content Edge Function

This function verifies the caller's Supabase Auth JWT, checks an active entitlement, and then creates a 60-second signed URL for the private full-size image.

## Secrets

Set these server-side Edge Function secrets (never in Flutter or browser code):

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SECRET_KEY` (the server-only Secret/service-role key shown in the Supabase dashboard)

## Deploy

```bash
supabase functions deploy get-protected-content
supabase secrets set SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY SUPABASE_SECRET_KEY=YOUR_SERVER_SECRET
```

`SUPABASE_URL` is available automatically in Supabase Edge Functions in current hosted environments; set it explicitly if your local setup requires it.

## Invoke

Send a POST request with the user's access token:

```json
{ "content_id": "00000000-0000-4000-8000-000000000000" }
```

The function returns a short-lived `signed_url` only if the authenticated user has an active entitlement for that content.
