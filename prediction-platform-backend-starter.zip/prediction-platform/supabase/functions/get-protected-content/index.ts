import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }

  const authorization = request.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) {
    return jsonResponse({ error: "Authentication required" }, 401);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const publishableKey = Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  const secretKey = Deno.env.get("SUPABASE_SECRET_KEY");

  if (!supabaseUrl || !publishableKey || !secretKey) {
    console.error("Missing Supabase function secrets");
    return jsonResponse({ error: "Server configuration error" }, 500);
  }

  // Validate the caller with their own JWT.
  const userClient = createClient(supabaseUrl, publishableKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: userData, error: userError } = await userClient.auth.getUser();
  if (userError || !userData.user) {
    return jsonResponse({ error: "Invalid or expired session" }, 401);
  }

  let body: { content_id?: string };
  try {
    body = await request.json();
  } catch {
    return jsonResponse({ error: "Request body must be valid JSON" }, 400);
  }

  const contentId = body.content_id;
  const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  if (!contentId || !uuidPattern.test(contentId)) {
    return jsonResponse({ error: "A valid content_id is required" }, 400);
  }

  // This client uses a server-only secret key. Never expose it to Flutter or the browser.
  const adminClient = createClient(supabaseUrl, secretKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: entitlement, error: entitlementError } = await adminClient
    .from("entitlements")
    .select("status, starts_at, expires_at")
    .eq("user_id", userData.user.id)
    .eq("content_id", contentId)
    .maybeSingle();

  if (entitlementError) {
    console.error("Entitlement lookup failed", entitlementError.message);
    return jsonResponse({ error: "Could not verify content access" }, 500);
  }

  const now = Date.now();
  const startsAt = entitlement?.starts_at ? Date.parse(entitlement.starts_at) : Number.POSITIVE_INFINITY;
  const expiresAt = entitlement?.expires_at ? Date.parse(entitlement.expires_at) : Number.POSITIVE_INFINITY;
  const hasAccess = entitlement?.status === "active" && startsAt <= now && expiresAt > now;

  if (!hasAccess) {
    return jsonResponse({ error: "Purchase required to access this content" }, 403);
  }

  const { data: asset, error: assetError } = await adminClient
    .from("prediction_private_assets")
    .select("full_image_path")
    .eq("content_id", contentId)
    .maybeSingle();

  if (assetError || !asset?.full_image_path) {
    console.error("Private asset lookup failed", assetError?.message ?? "Asset not found");
    return jsonResponse({ error: "Content asset is unavailable" }, 404);
  }

  // Signed URL is short-lived; keep the private bucket private.
  const { data: signed, error: signedError } = await adminClient.storage
    .from("prediction-full")
    .createSignedUrl(asset.full_image_path, 60);

  if (signedError || !signed?.signedUrl) {
    console.error("Signed URL creation failed", signedError?.message ?? "No URL returned");
    return jsonResponse({ error: "Could not provide content access" }, 500);
  }

  return jsonResponse({ signed_url: signed.signedUrl, expires_in: 60 });
});
