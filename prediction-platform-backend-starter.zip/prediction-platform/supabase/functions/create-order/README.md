# create-order Edge Function

Verifies the caller's Supabase Auth JWT, reads the current published content price from PostgreSQL, and creates a pending order plus an order item.

It does not charge the customer, mark the order paid, or grant access. Payment collection and entitlement creation must be added only after the business model, payment provider, and app distribution are confirmed eligible.

Use the same server-side secrets as `get-protected-content`:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SECRET_KEY`

Deploy:

```bash
supabase functions deploy create-order
```

Invoke with POST JSON:

```json
{ "content_id": "00000000-0000-4000-8000-000000000000" }
```

The client must send the user's Supabase access token in the Authorization header. Never accept a price or currency from the client.
