# Prediction Platform — Supabase Backend Starter

এই ZIP-এ Prediction Platform-এর **Backend Starter** ফাইলগুলো সঠিক ফোল্ডার কাঠামোয় সাজানো আছে। এটি এখনো সম্পূর্ণ Android App বা Admin Website নয়; Flutter ও Next.js অংশ পরবর্তী ডেভেলপমেন্ট ধাপে তৈরি হবে।

## অন্তর্ভুক্ত বিষয়

- PostgreSQL schema ও migration
- Profiles এবং Admin/Staff roles
- Thailand, Kuwait, Bahrain market seed
- 3D ও 4D prediction type
- আলাদা মূল্যসহ content catalogue
- Public preview এবং private full-image storage bucket
- Orders, order items, payments ও purchase entitlements
- Row Level Security (RLS) policies
- `create-order` Supabase Edge Function
- `get-protected-content` Supabase Edge Function
- Supabase CLI configuration

## গুরুত্বপূর্ণ সীমা

এই Starter Project অর্ডার তৈরি এবং কেনা কনটেন্টের অনুমতি যাচাইয়ের ভিত্তি দেয়। এটি এখনো কোনো Payment Gateway-তে টাকা সংগ্রহ করে না, Payment Webhook যাচাই করে না, এবং নিজে থেকে paid entitlement দেয় না। এসব কাজ কেবল ব্যবসায়িক/আইনগত যোগ্যতা, Payment Provider-এর অনুমোদন এবং App Store নীতিমালা যাচাইয়ের পর যুক্ত করতে হবে।

এখানে lottery ticket, wager, betting stake বা prize payout-এর ব্যবস্থা নেই। তবু 3D/4D prediction content বিক্রির বৈধতা সংশ্লিষ্ট দেশ ও প্ল্যাটফর্মের নিয়মে আলাদাভাবে যাচাই করতে হবে।

## 1. নতুন Supabase project তৈরি

1. https://supabase.com/dashboard খুলুন।
2. New project তৈরি করুন।
3. Database password নিরাপদ স্থানে রাখুন; GitHub বা chat-এ দেবেন না।
4. Project reference ও URL নোট করুন।

## 2. Migration চালানো

নতুন/খালি Supabase project-এর SQL Editor-এ নিচের ফাইলের সম্পূর্ণ SQL একবার চালান:

`supabase/migrations/20261119000100_initial_schema.sql`

এটি existing production database-এ সরাসরি চালাবেন না। আগে backup ও migration review প্রয়োজন। একই migration বারবার চালাবেন না।

## 3. প্রথম Super Admin তৈরি

1. Supabase Authentication থেকে নিজের account তৈরি করুন।
2. SQL Editor-এ নিজের registered email বসিয়ে নিচের query চালান:

```sql
insert into public.user_roles (user_id, role)
select id, 'super_admin'::public.app_role
from auth.users
where email = 'YOUR_ADMIN_EMAIL@example.com'
on conflict do nothing;
```

নিজের ইমেইল দিয়ে placeholder বদলাবেন। কোনো public registration form থেকে role নির্বাচন করতে দেবেন না।

## 4. Edge Function secrets

Supabase Edge Function-এর server-side secrets হিসেবে সেট করুন:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SECRET_KEY`

`SUPABASE_SECRET_KEY` কেবল server-side-এ থাকবে। Flutter, browser JavaScript বা GitHub-এ কখনো রাখবেন না। `.env.example`-এ শুধু placeholder আছে; সেটি বাস্তব key নয়।

## 5. Edge Functions deploy

Supabase CLI ইনস্টল ও login করার পর project root-এ:

```powershell
npx supabase login
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase functions deploy create-order
npx supabase functions deploy get-protected-content
```

Secrets সেট করার উদাহরণ:

```powershell
npx supabase secrets set SUPABASE_URL="https://YOUR_PROJECT_REF.supabase.co" SUPABASE_PUBLISHABLE_KEY="YOUR_PUBLISHABLE_KEY" SUPABASE_SECRET_KEY="YOUR_SERVER_SECRET_KEY"
```

বাস্তব secret terminal history, screenshot, public repository বা chat-এ প্রকাশ করবেন না।

## 6. Function-এর কাজ

### `create-order`

- Supabase Auth token যাচাই করে।
- Published content-এর বর্তমান মূল্য database থেকে নেয়।
- Pending order ও price snapshot তৈরি করে।
- নিজে থেকে payment collect বা content unlock করে না।

### `get-protected-content`

- Supabase Auth token যাচাই করে।
- User-এর active entitlement আছে কি না যাচাই করে।
- থাকলে private full image-এর 60-second signed URL দেয়।

## 7. GitHub-এ আপলোড করার নিয়ম

GitHub website-এর `Add file → Upload files` ZIP archive নিজে থেকে extract করে না। ZIP-টি এক ফাইল হিসেবে আপলোড করলে repository-তে শুধু ZIP-টাই দেখা যাবে।

সঠিক source folder tree GitHub-এ পেতে:

1. ZIP Extract করুন।
2. Extract করা folder-এর **ভেতরের সব ফাইল ও folder** GitHub repository-র root-এ upload করুন, অথবা GitHub Desktop দিয়ে repository folder-এ copy করে commit/push করুন।

Repository public রাখলে code public দেখা যাবে। Secret key কখনো commit করবেন না।

## Folder tree

```text
prediction-platform/
├── .env.example
├── .gitignore
├── README.md
└── supabase/
    ├── config.toml
    ├── migrations/
    │   └── 20261119000100_initial_schema.sql
    └── functions/
        ├── create-order/
        │   ├── README.md
        │   └── index.ts
        └── get-protected-content/
            ├── README.md
            └── index.ts
```

## Official documentation

- https://supabase.com/docs
- https://supabase.com/docs/guides/local-development
- https://supabase.com/docs/guides/functions
- https://supabase.com/docs/guides/database/postgres/row-level-security
