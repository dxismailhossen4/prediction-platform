# GitHub-এ একবারে সঠিক ফোল্ডারসহ আপলোড

**গুরুত্বপূর্ণ:** GitHub-এর ওয়েব `Upload files` পেজ ZIP নিজে থেকে খুলে দেয় না। ZIP-টি শুধু archive file হিসেবে commit হতে পারে।

## সহজ পদ্ধতি

1. `prediction-platform-backend-starter.zip` Extract করুন।
2. GitHub repository খুলুন।
3. `Add file` → `Upload files` চাপুন।
4. Extract করা folder-এর **ভেতরের** `README.md`, `.gitignore`, `.env.example` এবং `supabase` folder-সহ সব ফাইল/ফোল্ডার নির্বাচন করুন।
5. নিচে গিয়ে `Commit changes` চাপুন।

বিকল্প: GitHub Desktop-এ repository clone করে Extract করা ফাইলগুলো repository folder-এ copy করুন, তারপর Commit ও Push করুন।

**এই ZIP হলো Backend Starter। Flutter Android app ও Next.js Admin Website-এর source code এখনো তৈরি করা হয়নি।**
