# Prediction Platform - Supabase Backend Starter

This package contains an initial PostgreSQL migration for a Supabase project.

## Included

- User profiles and staff roles
- Thailand, Kuwait, and Bahrain market seeds
- 3D and 4D prediction types
- Individual-priced content catalogue
- Separate private full-image path table
- Orders, order items, payment records, entitlements
- Notifications and audit logs
- Row Level Security (RLS) policies
- Public preview and private full-image storage buckets

## Apply

1. Create a new Supabase project.
2. Open SQL Editor in the Supabase Dashboard.
3. Run `supabase/migrations/20261119000100_initial_schema.sql`.
4. Register your own account using Supabase Auth.
5. Run the administrator bootstrap SQL at the bottom of the migration after replacing the email.

## Important

- This is an initial database foundation, not a complete production payment system.
- Orders, order items, payments, and entitlements are intentionally not writable by client apps.
- Add trusted Edge Functions for order creation and payment-provider webhook verification after legal, provider, and platform eligibility checks.
- Never put Supabase secret/service-role keys in Flutter or browser code.
- Do not store full-resolution paid images in the public preview bucket.
- Run RLS tests before production launch.

## Edge Functions included

- `create-order`: verifies the signed-in user, loads the published item's current price from the database, and creates a pending order with a price snapshot. It does not charge money or grant access.
- `get-protected-content`: checks the caller's active entitlement and returns a 60-second signed URL for the private full-size image.

Deploy both with:

```bash
supabase functions deploy create-order
supabase functions deploy get-protected-content
```

Set `SUPABASE_PUBLISHABLE_KEY` and `SUPABASE_SECRET_KEY` as server-side Edge Function secrets. The Secret key must never be placed in the mobile app or browser.
